# SYBRO Android build setup

This folder contains the Android Gradle project needed by Flutter to build SYBRO.

Requirements on the build machine:
- Flutter SDK 3.x with Dart 3.4+
- Android SDK / build-tools
- Java 17+

The app id is `com.sybro.app` and the launcher icon is the supplied SYBRO logo.
