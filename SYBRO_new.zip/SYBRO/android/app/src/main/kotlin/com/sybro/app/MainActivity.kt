package com.sybro.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
