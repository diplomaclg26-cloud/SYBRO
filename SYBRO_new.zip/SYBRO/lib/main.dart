import 'dart:math';
import 'package:flutter/material.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'services/supabase_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  if (SupabaseService.isConfigured) {
    try {
      await SupabaseService.initialize();
    } catch (_) {
      // BootScreen shows a configuration error if initialization fails.
    }
  }
  runApp(const SybroApp());
}

class SybroApp extends StatelessWidget {
  const SybroApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'SYBRO',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(useMaterial3: true, brightness: Brightness.light, colorSchemeSeed: const Color(0xFF6C4CF1), scaffoldBackgroundColor: const Color(0xFFF8F7FC)),
    home: const BootScreen(),
  );
}

class BootScreen extends StatefulWidget {
  const BootScreen({super.key});
  @override State<BootScreen> createState() => _BootScreenState();
}
class _BootScreenState extends State<BootScreen> {
  String? error;
  @override void initState() { super.initState(); _open(); }
  Future<void> _open() async {
    await Future.delayed(const Duration(milliseconds: 900));
    if (!SupabaseService.isConfigured) {
      if (mounted) setState(() => error = 'Supabase is not configured yet.\nBuild with SUPABASE_URL and SUPABASE_ANON_KEY.');
      return;
    }
    try {
      final session = SupabaseService.client.auth.currentSession;
      await Future.delayed(const Duration(milliseconds: 500));
      if (!mounted) return;
      Navigator.of(context).pushReplacement(MaterialPageRoute(builder: (_) => session == null ? const LoginScreen() : const HomeScreen()));
    } catch (e) {
      if (mounted) setState(() => error = 'Could not connect to SYBRO backend.\n$e');
    }
  }
  @override Widget build(BuildContext context) => Scaffold(body: Center(child: Padding(padding: const EdgeInsets.all(28), child: Column(mainAxisSize: MainAxisSize.min, children: [const SybroLogo(size: 96), const SizedBox(height: 18), const Text('SYBRO', style: TextStyle(fontSize: 28, fontWeight: FontWeight.w800, letterSpacing: 3)), if (error != null) ...[const SizedBox(height: 28), Text(error!, textAlign: TextAlign.center, style: const TextStyle(color: Colors.red)), const SizedBox(height: 18), TextButton(onPressed: () { setState(() => error = null); _open(); }, child: const Text('Retry'))]]))));
}

class SybroLogo extends StatelessWidget {
  final double size; const SybroLogo({super.key, this.size = 44});
  @override Widget build(BuildContext context) => ClipRRect(borderRadius: BorderRadius.circular(size * .22), child: Image.asset('assets/images/sybro_logo.png', width: size, height: size, fit: BoxFit.cover));
}
class SybroBrand extends StatelessWidget {
  final double logoSize; const SybroBrand({super.key, this.logoSize = 34});
  @override Widget build(BuildContext context) => Row(mainAxisSize: MainAxisSize.min, children: [SybroLogo(size: logoSize), const SizedBox(width: 10), const Text('SYBRO', style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2))]);
}

class LoginScreen extends StatefulWidget { const LoginScreen({super.key}); @override State<LoginScreen> createState() => _LoginScreenState(); }
class _LoginScreenState extends State<LoginScreen> {
  final user = TextEditingController(); final pass = TextEditingController(); bool saving = false; bool obscure = true;
  Future<void> login() async {
    if (user.text.trim().isEmpty || pass.text.isEmpty) { snack(context, 'Enter username and password.'); return; }
    if (pass.text.length < 6) { snack(context, 'Password must be at least 6 characters.'); return; }
    setState(() => saving = true);
    try {
      throw const AuthException('Username login is being secured on the server. For this build, use the email address used for your SYBRO account.');
      if (!mounted) return;
      Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const HomeScreen()), (_) => false);
    } on AuthException catch (e) { if (mounted) snack(context, e.message); }
    catch (e) { if (mounted) snack(context, 'Login failed. Check your username/password and backend setup.'); }
    finally { if (mounted) setState(() => saving = false); }
  }
  @override Widget build(BuildContext context) => AuthScaffold(title: 'Welcome back', subtitle: 'Log in to your SYBRO account.', children: [Field(controller: user, label: 'Username', icon: Icons.person_outline), const SizedBox(height: 12), Field(controller: pass, label: 'Password', icon: Icons.lock_outline, obscureText: obscure, suffix: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined))), const SizedBox(height: 20), PrimaryButton(text: 'Log in', loading: saving, onPressed: login), const SizedBox(height: 12), TextButton(onPressed: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const SignupScreen())), child: const Text('Create new account'))]);
}

class SignupScreen extends StatefulWidget { const SignupScreen({super.key}); @override State<SignupScreen> createState() => _SignupScreenState(); }
class _SignupScreenState extends State<SignupScreen> {
  int step = 0; final first = TextEditingController(); final last = TextEditingController(); final username = TextEditingController(); final password = TextEditingController(); final email = TextEditingController(); bool obscure = true; bool taken = false; bool checking = false;
  Future<bool> available(String value) async { final result = await SupabaseService.client.rpc('username_available', params: {'p_username': value.trim()}); return result == true; }
  Future<void> suggest() async {
    final a = first.text.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), ''); final b = last.text.trim().toLowerCase().replaceAll(RegExp(r'[^a-z0-9]'), '');
    if (a.isEmpty && b.isEmpty) { snack(context, 'Enter your name first.'); return; }
    final base = a.isEmpty ? b : b.isEmpty ? a : '$a$b'; final r = Random();
    final candidates = [base, '${a.isNotEmpty ? a[0] : ''}$b${r.nextInt(90) + 10}', '$base${r.nextInt(900) + 100}', '$base${r.nextInt(9000) + 1000}'];
    for (final c in candidates) { if (c.length < 3 || c.length > 30) continue; try { if (await available(c)) { username.text = c; if (mounted) setState(() => taken = false); return; } } catch (_) {} }
    snack(context, 'Could not find a free username. Try again.');
  }
  Future<void> next() async {
    if (step == 0) { if (first.text.trim().isEmpty || last.text.trim().isEmpty) { snack(context, 'Enter your first and last name.'); return; } setState(() => step = 1); return; }
    if (step == 1) { final u = username.text.trim(); if (!RegExp(r'^[A-Za-z0-9._-]{3,30}$').hasMatch(u)) { snack(context, 'Username must be 3–30 letters, numbers, dot, underscore or hyphen.'); return; } setState(() => checking = true); try { final ok = await available(u); if (!ok) { setState(() { taken = true; checking = false; }); return; } setState(() { taken = false; checking = false; step = 2; }); } catch (_) { setState(() => checking = false); snack(context, 'Could not check username.'); } return; }
    if (step == 2) { if (password.text.length < 6) { snack(context, 'Password must be at least 6 characters.'); return; } setState(() => step = 3); return; }
    if (!RegExp(r'^[^@\s]+@[^@\s]+\.[^@\s]+$').hasMatch(email.text.trim())) { snack(context, 'Enter a valid email.'); return; }
    await createAccount();
  }
  Future<void> createAccount() async {
    setState(() => checking = true);
    try {
      final result = await SupabaseService.client.functions.invoke('start-signup', body: {'email': email.text.trim(), 'password': password.text, 'first_name': first.text.trim(), 'last_name': last.text.trim(), 'username': username.text.trim()});
      if (result.data is Map && result.data['ok'] == true) {
        if (!mounted) return;
        await Navigator.of(context).push(MaterialPageRoute(builder: (_) => OtpVerificationScreen(email: email.text.trim(), password: password.text)));
      } else {
        final msg = result.data is Map ? (result.data['error']?.toString() ?? 'Could not send verification code.') : 'Could not send verification code.';
        if (mounted) snack(context, msg);
      }
    } on FunctionException catch (e) { if (mounted) snack(context, e.details?.toString() ?? e.reasonPhrase ?? 'Could not send verification code.'); }
    catch (e) { if (mounted) snack(context, 'Could not send verification code. $e'); }
    finally { if (mounted) setState(() => checking = false); }
  }
  @override Widget build(BuildContext context) {
    final titles = ['Your name', 'Choose username', 'Create password', 'Your email'];
    return AuthScaffold(title: titles[step], subtitle: 'Step ${step + 1} of 4', children: [
      if (step == 0) ...[Field(controller: first, label: 'First name', icon: Icons.badge_outlined), const SizedBox(height: 12), Field(controller: last, label: 'Last name', icon: Icons.badge_outlined)],
      if (step == 1) ...[Field(controller: username, label: 'Username', icon: Icons.alternate_email, onChanged: (_) { if (taken) setState(() => taken = false); }, suffix: IconButton(onPressed: checking ? null : suggest, icon: const Text('🎲', style: TextStyle(fontSize: 22)))), if (taken) const Padding(padding: EdgeInsets.only(top: 8), child: Align(alignment: Alignment.centerLeft, child: Text('username already taken try new user name', style: TextStyle(color: Colors.red)))), const SizedBox(height: 8), TextButton.icon(onPressed: checking ? null : suggest, icon: const Text('🎲'), label: const Text('Suggest a unique username'))],
      if (step == 2) ...[Field(controller: password, label: 'Create password', icon: Icons.lock_outline, obscureText: obscure, suffix: IconButton(onPressed: () => setState(() => obscure = !obscure), icon: Icon(obscure ? Icons.visibility_outlined : Icons.visibility_off_outlined))), const SizedBox(height: 8), const Align(alignment: Alignment.centerLeft, child: Text('Minimum 6 characters.'))],
      if (step == 3) Field(controller: email, label: 'Email address', icon: Icons.email_outlined, keyboardType: TextInputType.emailAddress),
      const SizedBox(height: 20), PrimaryButton(text: step == 3 ? 'Send code' : 'Next', loading: checking, onPressed: next),
      if (step > 0) TextButton(onPressed: checking ? null : () => setState(() => step--), child: const Text('Back')),
    ]);
  }
}

class OtpVerificationScreen extends StatefulWidget {
  final String email; final String password;
  const OtpVerificationScreen({super.key, required this.email, required this.password});
  @override State<OtpVerificationScreen> createState() => _OtpVerificationScreenState();
}
class _OtpVerificationScreenState extends State<OtpVerificationScreen> {
  final code = TextEditingController(); bool loading = false;
  Future<void> verify() async {
    if (!RegExp(r'^\d{4}$').hasMatch(code.text.trim())) { snack(context, 'Enter the 4-digit code.'); return; }
    setState(() => loading = true);
    try {
      final result = await SupabaseService.client.functions.invoke('verify-signup', body: {'email': widget.email, 'code': code.text.trim()});
      if (result.data is Map && result.data['ok'] == true) {
        await SupabaseService.client.auth.signInWithPassword(email: widget.email, password: widget.password);
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const HomeScreen()), (_) => false);
      } else {
        final msg = result.data is Map ? (result.data['error']?.toString() ?? 'Verification failed.') : 'Verification failed.';
        if (mounted) snack(context, msg);
      }
    } on FunctionException catch (e) { if (mounted) snack(context, e.details?.toString() ?? e.reasonPhrase ?? 'Verification failed.'); }
    catch (e) { if (mounted) snack(context, 'Verification failed. $e'); }
    finally { if (mounted) setState(() => loading = false); }
  }
  @override Widget build(BuildContext context) => AuthScaffold(title: 'Verify your email', subtitle: 'Enter the 4-digit code sent to ${widget.email}.', children: [
    TextField(controller: code, keyboardType: TextInputType.number, maxLength: 4, textAlign: TextAlign.center, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800, letterSpacing: 12), decoration: InputDecoration(labelText: '4-digit code', prefixIcon: const Icon(Icons.verified_outlined), border: OutlineInputBorder(borderRadius: BorderRadius.circular(16))),),
    const SizedBox(height: 20), PrimaryButton(text: 'Verify', loading: loading, onPressed: verify),
  ]);
}

class AuthScaffold extends StatelessWidget { final String title, subtitle; final List<Widget> children; const AuthScaffold({super.key, required this.title, required this.subtitle, required this.children}); @override Widget build(BuildContext context) => Scaffold(body: SafeArea(child: Center(child: SingleChildScrollView(padding: const EdgeInsets.all(24), child: ConstrainedBox(constraints: const BoxConstraints(maxWidth: 460), child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [const Center(child: SybroLogo(size: 70)), const SizedBox(height: 24), Text(title, style: const TextStyle(fontSize: 30, fontWeight: FontWeight.w800)), const SizedBox(height: 6), Text(subtitle, style: TextStyle(color: Colors.grey.shade700)), const SizedBox(height: 28), ...children])))))); }

class HomeScreen extends StatefulWidget { const HomeScreen({super.key}); @override State<HomeScreen> createState() => _HomeScreenState(); }
class _HomeScreenState extends State<HomeScreen> {
  int index = 0;
  final pages = const [Center(child: Text('Home Feed', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700))), Center(child: Text('Reels', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700))), Center(child: Text('Messages', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700))), Center(child: Text('Search', style: TextStyle(fontSize: 24, fontWeight: FontWeight.w700))), YouPage()];
  Future<void> logout() async { await SupabaseService.client.auth.signOut(); if (!mounted) return; Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false); }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const SybroBrand(logoSize: 34), actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))]), body: pages[index], floatingActionButton: index == 0 ? FloatingActionButton(onPressed: () {}, child: const Icon(Icons.add)) : null, bottomNavigationBar: NavigationBar(selectedIndex: index, onDestinationSelected: (i) => setState(() => index = i), destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'), NavigationDestination(icon: Icon(Icons.movie_outlined), selectedIcon: Icon(Icons.movie), label: 'Reels'), NavigationDestination(icon: Icon(Icons.chat_bubble_outline), selectedIcon: Icon(Icons.chat_bubble), label: 'Messages'), NavigationDestination(icon: Icon(Icons.search), label: 'Search'), NavigationDestination(icon: Icon(Icons.person_outline), selectedIcon: Icon(Icons.person), label: 'You')]));
}

class YouPage extends StatelessWidget { const YouPage({super.key});
  Future<void> logout(BuildContext context) async { await SupabaseService.client.auth.signOut(); if (!context.mounted) return; Navigator.of(context).pushAndRemoveUntil(MaterialPageRoute(builder: (_) => const LoginScreen()), (_) => false); }
  Future<Map<String, dynamic>?> profile() async { final id = SupabaseService.client.auth.currentUser?.id; if (id == null) return null; return await SupabaseService.client.from('profiles').select().eq('id', id).maybeSingle(); }
  @override Widget build(BuildContext context) => FutureBuilder<Map<String, dynamic>?>(future: profile(), builder: (context, snapshot) { final p = snapshot.data; final username = p?['username']?.toString() ?? 'username'; final display = p?['display_name']?.toString() ?? 'Your Name'; return ListView(padding: const EdgeInsets.all(20), children: [Row(children: [const CircleAvatar(radius: 42, child: Icon(Icons.person, size: 42)), const SizedBox(width: 16), Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text(display, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.w800)), Text('@$username', style: TextStyle(color: Colors.grey.shade700)), Text('${p?['followers_count'] ?? 0} followers  •  ${p?['following_count'] ?? 0} following', style: TextStyle(color: Colors.grey.shade700))]))]), const SizedBox(height: 28), const ListTile(leading: Icon(Icons.edit_outlined), title: Text('Edit profile')), const ListTile(leading: Icon(Icons.people_outline), title: Text('Followers / Following')), const ListTile(leading: Icon(Icons.settings_outlined), title: Text('Settings')), const Divider(), ListTile(leading: const Icon(Icons.swap_horiz), title: const Text('Switch account'), onTap: () {}), ListTile(leading: const Icon(Icons.logout), title: const Text('Log out'), onTap: () => logout(context))]); });
}

class Field extends StatelessWidget { final TextEditingController controller; final String label; final IconData icon; final bool obscureText; final Widget? suffix; final ValueChanged<String>? onChanged; final TextInputType? keyboardType; final int? maxLength; const Field({super.key, required this.controller, required this.label, required this.icon, this.obscureText = false, this.suffix, this.onChanged, this.keyboardType, this.maxLength}); @override Widget build(BuildContext context) => TextField(controller: controller, obscureText: obscureText, onChanged: onChanged, keyboardType: keyboardType, maxLength: maxLength, decoration: InputDecoration(labelText: label, prefixIcon: Icon(icon), suffixIcon: suffix, border: OutlineInputBorder(borderRadius: BorderRadius.circular(16)))); }
class PrimaryButton extends StatelessWidget { final String text; final VoidCallback onPressed; final bool loading; const PrimaryButton({super.key, required this.text, required this.onPressed, this.loading = false}); @override Widget build(BuildContext context) => SizedBox(height: 54, child: FilledButton(onPressed: loading ? null : onPressed, child: loading ? const SizedBox(width: 22, height: 22, child: CircularProgressIndicator(strokeWidth: 2)) : Text(text, style: const TextStyle(fontWeight: FontWeight.w700)))); }
void snack(BuildContext context, String message) => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
