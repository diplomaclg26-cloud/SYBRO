import 'package:supabase_flutter/supabase_flutter.dart';

class SupabaseService {
  static SupabaseClient get client => Supabase.instance.client;

  static Future<void> initialize() async {
    const url = String.fromEnvironment(
      'SUPABASE_URL',
      defaultValue: 'https://kchzjrppboquqqjesqxu.supabase.co',
    );
    const anonKey = String.fromEnvironment(
      'SUPABASE_ANON_KEY',
      defaultValue: 'sb_publishable_PvT2kFLPm5TLGvHAgx1TTQ_1snk6Z1c',
    );

    if (url.isEmpty || anonKey.isEmpty) {
      throw StateError(
        'Missing Supabase configuration.',
      );
    }

    await Supabase.initialize(url: url, anonKey: anonKey);
  }

  static bool get isConfigured {
    const url = String.fromEnvironment(
      'SUPABASE_URL',
      defaultValue: 'https://kchzjrppboquqqjesqxu.supabase.co',
    );
    const key = String.fromEnvironment(
      'SUPABASE_ANON_KEY',
      defaultValue: 'sb_publishable_PvT2kFLPm5TLGvHAgx1TTQ_1snk6Z1c',
    );
    return url.isNotEmpty && key.isNotEmpty;
  }
}
