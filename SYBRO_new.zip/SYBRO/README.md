# SYBRO

SYBRO is a Flutter + Supabase social app foundation using the supplied SYBRO logo.

## Current foundation
- Real Supabase Auth initialization
- Supabase `profiles` table + RLS policies
- Unique username availability RPC
- Real signup with Supabase Auth
- Email confirmation handled by Supabase Auth
- Supabase session restore
- Official SYBRO logo in app assets and Android launcher
- Android Gradle project included for Flutter builds

## Important
Do not put a Supabase secret/service-role key in the app. The publishable key is intended for client use.

Username-to-email login is intentionally not exposed through the public database API. A trusted server/Edge Function should be added before enabling username/password login, so a username cannot be used to enumerate private email addresses.

## Build
On a machine with Flutter installed:

```bash
flutter pub get
flutter run
# or
flutter build apk --debug
# release store package
flutter build appbundle --release
```

## SYBRO 4-digit email verification
This build adds a real server-side 4-digit signup verification flow using Supabase Edge Functions and Resend. Supabase's native email OTP is 6 digits minimum, so the exact 4-digit SYBRO requirement needs this custom server flow.

### One-time Supabase setup
1. Run the updated `supabase/schema.sql` in Supabase SQL Editor.
2. Deploy `supabase/functions/start-signup` and `supabase/functions/verify-signup` as Edge Functions.
3. In Edge Function Secrets, add `RESEND_API_KEY`.
4. Add `SYBRO_FROM_EMAIL` as a verified sender address in Resend (or omit it while testing with a permitted Resend sender).
5. The Edge Functions use Supabase's server-side `SUPABASE_SERVICE_ROLE_KEY`; never put that key in Flutter, GitHub, or the public repo.

Supabase docs: https://supabase.com/docs/guides/functions/examples/send-emails
Resend integration: https://supabase.com/partners/resend
