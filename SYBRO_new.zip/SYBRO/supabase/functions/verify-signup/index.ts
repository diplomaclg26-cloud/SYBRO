import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const admin = createClient(supabaseUrl, serviceRoleKey, { auth: { autoRefreshToken: false, persistSession: false } })
const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })
const hash = async (value: string) => {
  const bytes = new TextEncoder().encode(value)
  const digest = await crypto.subtle.digest('SHA-256', bytes)
  return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('')
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)
  try {
    const { email, code } = await req.json()
    const cleanEmail = String(email ?? '').trim().toLowerCase()
    const cleanCode = String(code ?? '').trim()
    if (!/^\d{4}$/.test(cleanCode)) return json({ error: 'Enter the 4-digit code.' }, 400)
    const { data: user } = await admin.from('email_otps').select('user_id,code_hash,expires_at').eq('email', cleanEmail).order('created_at', { ascending: false }).limit(1).maybeSingle()
    if (!user) return json({ error: 'Verification code not found. Request a new code.' }, 404)
    if (new Date(user.expires_at).getTime() < Date.now()) return json({ error: 'Code expired. Please create the account again.' }, 410)
    const expected = await hash(`${user.user_id}:${cleanCode}`)
    if (expected !== user.code_hash) return json({ error: 'Incorrect verification code.' }, 401)

    const { error: confirmError } = await admin.auth.admin.updateUserById(user.user_id, { email_confirm: true })
    if (confirmError) return json({ error: confirmError.message }, 500)
    await admin.from('email_otps').delete().eq('user_id', user.user_id)
    return json({ ok: true })
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : 'Unexpected error' }, 500)
  }
})
