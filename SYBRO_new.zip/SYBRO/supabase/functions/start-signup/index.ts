import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const supabaseUrl = Deno.env.get('SUPABASE_URL')!
const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
const resendKey = Deno.env.get('RESEND_API_KEY')!
const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, { auth: { autoRefreshToken: false, persistSession: false } })

const json = (body: unknown, status = 200) => new Response(JSON.stringify(body), { status, headers: { 'Content-Type': 'application/json' } })
const hash = async (value: string) => {
  const bytes = new TextEncoder().encode(value)
  const digest = await crypto.subtle.digest('SHA-256', bytes)
  return Array.from(new Uint8Array(digest)).map(b => b.toString(16).padStart(2, '0')).join('')
}

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ error: 'Method not allowed' }, 405)
  try {
    const { email, password, first_name, last_name, username } = await req.json()
    const cleanEmail = String(email ?? '').trim().toLowerCase()
    const cleanUsername = String(username ?? '').trim()
    if (!cleanEmail || !password || String(password).length < 6 || !first_name || !last_name || !cleanUsername) return json({ error: 'Invalid signup details' }, 400)

    const { data: available, error: usernameError } = await supabaseAdmin.rpc('username_available', { p_username: cleanUsername })
    if (usernameError || available !== true) return json({ error: 'username already taken try new user name' }, 409)

    const { data: created, error: createError } = await supabaseAdmin.auth.admin.createUser({
      email: cleanEmail,
      password: String(password),
      email_confirm: false,
      user_metadata: { first_name: String(first_name).trim(), last_name: String(last_name).trim(), username: cleanUsername },
    })
    if (createError) return json({ error: createError.message }, 400)
    const userId = created.user?.id
    if (!userId) return json({ error: 'Could not create account' }, 500)

    const code = String(Math.floor(1000 + Math.random() * 9000))
    const codeHash = await hash(`${userId}:${code}`)
    await supabaseAdmin.from('email_otps').delete().eq('user_id', userId)
    const { error: otpError } = await supabaseAdmin.from('email_otps').insert({ user_id: userId, email: cleanEmail, code_hash: codeHash, expires_at: new Date(Date.now() + 10 * 60 * 1000).toISOString() })
    if (otpError) return json({ error: 'Could not create verification code' }, 500)

    const emailResponse = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', Authorization: `Bearer ${resendKey}` },
      body: JSON.stringify({
        from: Deno.env.get('SYBRO_FROM_EMAIL') ?? 'SYBRO <onboarding@resend.dev>',
        to: [cleanEmail],
        subject: 'Your SYBRO verification code',
        html: `<div style="font-family:Arial,sans-serif"><h2>Welcome to SYBRO</h2><p>Your verification code is:</p><div style="font-size:32px;font-weight:700;letter-spacing:8px">${code}</div><p>This code expires in 10 minutes.</p></div>`,
      }),
    })
    if (!emailResponse.ok) {
      const details = await emailResponse.text()
      return json({ error: `Email could not be sent: ${details}` }, 502)
    }
    return json({ ok: true })
  } catch (e) {
    return json({ error: e instanceof Error ? e.message : 'Unexpected error' }, 500)
  }
})
