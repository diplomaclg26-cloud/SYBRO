# SYBRO

SYBRO is a Flutter + Supabase social app foundation using the supplied SYBRO logo.

## Current foundation
- Real Supabase Auth initialization
- Supabase `profiles` table + RLS policies
- Unique username availability RPC
- Real signup with Supabase Auth
- Email confirmation handled by Supabase Auth
- Supabase session restore
- Official SYBRO logo in app assets and Android launcher
- Android Gradle project included for Flutter builds

## Important
Do not put a Supabase secret/service-role key in the app. The publishable key is intended for client use.

Username-to-email login is intentionally not exposed through the public database API. A trusted server/Edge Function should be added before enabling username/password login, so a username cannot be used to enumerate private email addresses.

## Build
On a machine with Flutter installed:

```bash
flutter pub get
flutter run
# or
flutter build apk --debug
# release store package
flutter build appbundle --release
```
